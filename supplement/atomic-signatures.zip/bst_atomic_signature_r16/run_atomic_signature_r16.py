#!/usr/bin/env python3
from __future__ import annotations

import csv
import hashlib
import json
import math
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve().parent
INPUTS = HERE / "inputs"
OUTPUTS = HERE / "outputs"

LOW_K = INPUTS / "v94_r6_contact_load_identity_operators_H_Kr.npz"
HIGH_K = INPUTS / "v94_r9_upper_contact_load_identity_operators_Z37_Z118.npz"
LOW_BASIS = INPUTS / "v94_r4_lower_common_action_bases_H_Kr.npz"
HIGH_BASIS = INPUTS / "v92_r1_upper_atomic_bases_Z37_Z118.npz"
R8 = INPUTS / "v94_r8_v68_full_operator_14_pair_revalidation.json"
R10 = INPUTS / "v94_r10_stratified_upper_full_operator_wells.json"

SYMBOLS = (
    "H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co Ni Cu Zn "
    "Ga Ge As Se Br Kr Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb Te I Xe Cs Ba La Ce "
    "Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu Hf Ta W Re Os Ir Pt Au Hg Tl Pb Bi Po At Rn "
    "Fr Ra Ac Th Pa U Np Pu Am Cm Bk Cf Es Fm Md No Lr Rf Db Sg Bh Hs Mt Ds Rg Cn Nh Fl "
    "Mc Lv Ts Og"
).split()

ZERO_TOL = 1.0e-10


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def orthonormal_span(columns: np.ndarray, previous: np.ndarray | None = None) -> np.ndarray:
    a = np.asarray(columns, dtype=float)
    if a.ndim == 1:
        a = a[:, None]
    if previous is not None and previous.size:
        a = a - previous @ (previous.T @ a)
    if not a.size:
        return np.empty((len(columns), 0))
    u, s, _ = np.linalg.svd(a, full_matrices=False)
    keep = s > max(1.0e-12, (s[0] if len(s) else 0.0) * 1.0e-10)
    return u[:, keep]


def multipole_spaces(shell: np.ndarray) -> dict[int, np.ndarray]:
    x = shell / np.linalg.norm(shell, axis=1, keepdims=True)
    a, b, c = x.T
    q0 = orthonormal_span(np.ones((len(x), 1)))
    q1 = orthonormal_span(np.column_stack([a, b, c]), q0)
    p01 = np.column_stack([q0, q1])
    q2 = orthonormal_span(
        np.column_stack([a * b, b * c, c * a, a * a - b * b, 3 * c * c - 1]), p01
    )
    p012 = np.column_stack([p01, q2])
    q3 = orthonormal_span(
        np.column_stack([
            a * (5 * a * a - 3), b * (5 * b * b - 3), c * (5 * c * c - 3),
            a * (b * b - c * c), b * (c * c - a * a), c * (a * a - b * b), a * b * c,
        ]),
        p012,
    )
    return {0: q0, 1: q1, 2: q2, 3: q3}


def fixed_directions() -> np.ndarray:
    rows = []
    for a in (-1, 0, 1):
        for b in (-1, 0, 1):
            for c in (-1, 0, 1):
                if (a, b, c) != (0, 0, 0):
                    v = np.asarray([a, b, c], dtype=float)
                    rows.append(v / np.linalg.norm(v))
    return np.asarray(rows)


def contact_signature(evals: np.ndarray, evecs: np.ndarray, shell: np.ndarray, direction: np.ndarray) -> dict:
    direction = np.asarray(direction, dtype=float)
    direction /= np.linalg.norm(direction)
    unit = shell / np.linalg.norm(shell, axis=1, keepdims=True)
    load = np.maximum(unit @ direction, 0.0)
    if not np.any(load > 0.0):
        load[int(np.argmax(unit @ direction))] = 1.0
    load -= load.mean()
    norm = np.linalg.norm(load)
    if norm <= 1.0e-14:
        raise ValueError("degenerate contact load")
    load /= norm
    amplitude = evecs.T @ load
    weights = amplitude * amplitude
    weights /= weights.sum()
    omega = np.sqrt(evals)
    compliance = float(np.sum(weights / evals))
    return {
        "stiffness": 1.0 / compliance,
        "compliance": compliance,
        "modal_latency": float(np.sum(weights / omega)),
        "weighted_omega": float(np.sum(weights * omega)),
        "rms_omega": float(np.sqrt(np.sum(weights * evals))),
        "weights": weights,
    }


def load_banks():
    stores = [
        np.load(LOW_K), np.load(HIGH_K), np.load(LOW_BASIS), np.load(HIGH_BASIS)
    ]

    def get(z: int, suffix: str) -> np.ndarray:
        key = f"Z{z:03d}_{suffix}"
        for store in stores:
            if key in store:
                return np.asarray(store[key])
        raise KeyError(key)

    return stores, get


def spectral_bank(get):
    directions = fixed_directions()
    atoms = {}
    mode_rows = []
    signature_rows = []
    for z in range(1, 119):
        k = get(z, "contact_load_identity_operator")
        shell = get(z, "shell")
        radius = float(get(z, "radius"))
        if k.shape != (len(shell), len(shell)):
            raise AssertionError(f"Z={z}: operator/shell shape mismatch")
        k = 0.5 * (k + k.T)
        all_evals, all_evecs = np.linalg.eigh(k)
        positive = all_evals > ZERO_TOL
        evals = all_evals[positive]
        evecs = all_evecs[:, positive]
        spaces = multipole_spaces(shell)
        contact_x = contact_signature(evals, evecs, shell, np.array([1.0, 0.0, 0.0]))
        directional = [contact_signature(evals, evecs, shell, d)["stiffness"] for d in directions]

        weights_by_l = {}
        for ell in (1, 2, 3):
            q = spaces[ell]
            weights_by_l[ell] = np.sum((q.T @ evecs) ** 2, axis=0) if q.size else np.zeros(len(evals))
        residual = np.maximum(0.0, 1.0 - sum(weights_by_l.values()))

        band = 0
        prior = None
        band_ids = []
        for value in evals:
            if prior is None or abs(value - prior) > 1.0e-4 * max(abs(value), abs(prior), 1.0e-12):
                band += 1
            band_ids.append(band)
            prior = value
        multiplicities = {bid: band_ids.count(bid) for bid in set(band_ids)}

        for index, (lam, bid) in enumerate(zip(evals, band_ids)):
            labels = {1: "dipole", 2: "quadrupole", 3: "octupole", 4: "residual"}
            parts = [weights_by_l[1][index], weights_by_l[2][index], weights_by_l[3][index], residual[index]]
            mode_rows.append({
                "Z": z,
                "symbol": SYMBOLS[z - 1],
                "mode_index": index + 1,
                "band_id": bid,
                "band_multiplicity": multiplicities[bid],
                "eigenvalue": float(lam),
                "omega_internal": float(math.sqrt(lam)),
                "dipole_weight": float(parts[0]),
                "quadrupole_weight": float(parts[1]),
                "octupole_weight": float(parts[2]),
                "residual_weight": float(parts[3]),
                "dominant_geometry": labels[int(np.argmax(parts)) + 1],
                "canonical_contact_weight": float(contact_x["weights"][index]),
            })

        stiffness_min = float(min(directional))
        stiffness_max = float(max(directional))
        row = {
            "Z": z,
            "symbol": SYMBOLS[z - 1],
            "surface_nodes": len(shell),
            "radius": radius,
            "null_mode_count": int(np.count_nonzero(~positive)),
            "positive_mode_count": len(evals),
            "band_count": band,
            "omega_min": float(np.sqrt(evals[0])),
            "omega_max": float(np.sqrt(evals[-1])),
            "omega_spread_relative": float(np.sqrt(evals[-1] / evals[0]) - 1.0),
            "contact_stiffness_x": contact_x["stiffness"],
            "contact_compliance_x": contact_x["compliance"],
            "contact_modal_latency_x": contact_x["modal_latency"],
            "contact_weighted_omega_x": contact_x["weighted_omega"],
            "directional_stiffness_min": stiffness_min,
            "directional_stiffness_max": stiffness_max,
            "directional_anisotropy": stiffness_max / stiffness_min - 1.0,
        }
        signature_rows.append(row)
        atoms[z] = {"evals": evals, "evecs": evecs, "shell": shell, "summary": row}
    return atoms, mode_rows, signature_rows


def pair_features(pair: dict, atoms: dict) -> dict:
    axis = np.array([1.0, 0.0, 0.0])
    rotation = np.asarray(pair["rotation_matrix"], dtype=float)
    left = atoms[int(pair["Z1"])]
    right = atoms[int(pair["Z2"])]
    ls = contact_signature(left["evals"], left["evecs"], left["shell"], axis)
    right_local_direction = rotation.T @ (-axis)
    rs = contact_signature(right["evals"], right["evecs"], right["shell"], right_local_direction)
    k_pair = 1.0 / (1.0 / ls["stiffness"] + 1.0 / rs["stiffness"])
    predicted = math.sqrt(k_pair / float(pair["reduced_wave_mass"]))

    li = np.argsort(ls["weights"])[-16:][::-1]
    ri = np.argsort(rs["weights"])[-16:][::-1]
    accords = []
    for i in li:
        for j in ri:
            wl = math.sqrt(float(left["evals"][i]))
            wr = math.sqrt(float(right["evals"][j]))
            weight = float(ls["weights"][i] * rs["weights"][j])
            accords.append({
                "left_mode": int(i + 1), "right_mode": int(j + 1), "joint_weight": weight,
                "left_omega": wl, "right_omega": wr,
                "beat_abs_difference": abs(wl - wr), "sum": wl + wr,
                "series_chord": (wl * wr) / math.sqrt(wl * wl + wr * wr),
            })
    accords.sort(key=lambda row: row["joint_weight"], reverse=True)
    return {
        "predicted_omega_raw": predicted,
        "left_contact_stiffness": ls["stiffness"],
        "right_contact_stiffness": rs["stiffness"],
        "pair_series_stiffness": k_pair,
        "left_modal_latency": ls["modal_latency"],
        "right_modal_latency": rs["modal_latency"],
        "radius_asymmetry": abs(left["summary"]["radius"] - right["summary"]["radius"]) /
            (left["summary"]["radius"] + right["summary"]["radius"]),
        "nuclear_asymmetry": abs(int(pair["Z1"]) - int(pair["Z2"])) /
            (int(pair["Z1"]) + int(pair["Z2"])),
        "top_modal_accords": accords[:12],
    }


def spearman(x: list[float], y: list[float]) -> float:
    def ranks(values):
        order = np.argsort(values)
        r = np.empty(len(values), dtype=float)
        r[order] = np.arange(len(values), dtype=float)
        return r
    if len(x) < 2:
        return float("nan")
    return float(np.corrcoef(ranks(x), ranks(y))[0, 1])


def metrics(rows: list[dict], prediction_key: str) -> dict:
    errors = [abs(row[prediction_key] / row["measured_omega"] - 1.0) for row in rows]
    return {
        "count": len(rows),
        "mape": float(np.mean(errors)),
        "median_absolute_percentage_error": float(np.median(errors)),
        "maximum_relative_error": float(max(errors)),
        "spearman_rank": spearman(
            [row[prediction_key] for row in rows], [row["measured_omega"] for row in rows]
        ),
    }


def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    OUTPUTS.mkdir(exist_ok=True)
    stores, get = load_banks()
    atoms, modes, signatures = spectral_bank(get)
    for store in stores:
        store.close()
    write_csv(OUTPUTS / "BST_ATOMIC_MODE_BANK_Z001_Z118_R16.csv", modes)
    write_csv(OUTPUTS / "BST_ATOMIC_SIGNATURE_SUMMARY_Z001_Z118_R16.csv", signatures)

    r8 = json.loads(R8.read_text(encoding="utf-8"))
    r10 = json.loads(R10.read_text(encoding="utf-8"))
    panels = {"R8_CALIBRATION": r8["pairs"], "R10_HELD_OUT": r10["pairs"]}
    positive_rows = []
    controls = {}
    accords = {}
    for panel, pairs in panels.items():
        for name, pair in pairs.items():
            if pair["dynamics"] is None:
                controls[f"{panel}:{name}"] = {
                    "bound_candidate": bool(pair["fit"]["bound_candidate"]),
                    "dynamics_present": False,
                }
                continue
            feat = pair_features(pair, atoms)
            measured = float(pair["dynamics"]["fine"]["measured_angular_frequency"])
            positive_rows.append({
                "panel": panel, "pair": name, "Z1": int(pair["Z1"]), "Z2": int(pair["Z2"]),
                "measured_omega": measured,
                "predicted_omega_raw": feat["predicted_omega_raw"],
                "predicted_omega_scaled": float("nan"),
                "radius_asymmetry": feat["radius_asymmetry"],
                "nuclear_asymmetry": feat["nuclear_asymmetry"],
                "left_contact_stiffness": feat["left_contact_stiffness"],
                "right_contact_stiffness": feat["right_contact_stiffness"],
                "left_modal_latency": feat["left_modal_latency"],
                "right_modal_latency": feat["right_modal_latency"],
            })
            accords[f"{panel}:{name}"] = feat["top_modal_accords"]

    calibration = [row for row in positive_rows if row["panel"] == "R8_CALIBRATION"]
    holdout = [row for row in positive_rows if row["panel"] == "R10_HELD_OUT"]
    log_scale = float(np.mean([
        math.log(row["measured_omega"] / row["predicted_omega_raw"]) for row in calibration
    ]))
    global_scale = math.exp(log_scale)
    for row in positive_rows:
        row["predicted_omega_scaled"] = row["predicted_omega_raw"] * global_scale
    write_csv(OUTPUTS / "BST_ATOMIC_TO_PAIR_TRANSFER_R16.csv", positive_rows)
    (OUTPUTS / "BST_MODAL_ACCORDS_R16.json").write_text(
        json.dumps(accords, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    atomic_gate = (
        len(signatures) == 118 and
        all(row["null_mode_count"] == 1 for row in signatures) and
        all(row["positive_mode_count"] == row["surface_nodes"] - 1 for row in signatures)
    )
    control_gate = len(controls) == 7 and all(not row["bound_candidate"] for row in controls.values())
    holdout_metrics = metrics(holdout, "predicted_omega_scaled")
    transfer_gate = (
        holdout_metrics["mape"] <= 0.15 and
        holdout_metrics["maximum_relative_error"] <= 0.25 and
        holdout_metrics["spearman_rank"] >= 0.90
    )
    universal = atomic_gate and control_gate and transfer_gate
    report = {
        "stage": "BST_ATOMIC_SIGNATURE_AND_MODAL_COMPOSITION_R16",
        "input_sha256": {path.name: sha256(path) for path in [LOW_K, HIGH_K, LOW_BASIS, HIGH_BASIS, R8, R10]},
        "method": {
            "atomic_frequency": "sqrt(eigenvalue of full contact-load identity operator)",
            "contact_load": "positive hemisphere ramp, mean removed, unit norm",
            "pair_composition": "series compliance divided by frozen reduced wave mass",
            "global_scale_fit": "geometric log scale on R8 only",
            "molecule_specific_parameters": 0,
            "element_specific_fitted_parameters": 0,
        },
        "atomic_bank": {
            "atom_count": len(signatures), "mode_count": len(modes),
            "all_atoms_one_uniform_null_mode": atomic_gate,
            "median_internal_relative_spread": float(np.median([r["omega_spread_relative"] for r in signatures])),
            "maximum_internal_relative_spread": float(max(r["omega_spread_relative"] for r in signatures)),
            "median_directional_anisotropy": float(np.median([r["directional_anisotropy"] for r in signatures])),
            "maximum_directional_anisotropy": float(max(r["directional_anisotropy"] for r in signatures)),
        },
        "negative_controls": controls,
        "negative_control_gate_pass": control_gate,
        "calibration": {
            "panel": "R8 lower pairs", "global_scale": global_scale,
            "raw_metrics": metrics(calibration, "predicted_omega_raw"),
            "scaled_metrics": metrics(calibration, "predicted_omega_scaled"),
        },
        "held_out_transfer": {
            "panel": "R10 upper pairs; absent from scale fitting",
            "elements": sorted(set(sum(([row["Z1"], row["Z2"]] for row in holdout), []))),
            "metrics": holdout_metrics,
            "gates": {
                "mape_le_15pct": holdout_metrics["mape"] <= 0.15,
                "maximum_error_le_25pct": holdout_metrics["maximum_relative_error"] <= 0.25,
                "spearman_ge_0_90": holdout_metrics["spearman_rank"] >= 0.90,
                "pass": transfer_gate,
            },
        },
        "universal_law_qualified": universal,
        "verdict": (
            "UNIVERSAL_ATOMIC_SIGNATURE_COMPOSITION_QUALIFIED" if universal else
            "ATOMIC_SIGNATURE_BANK_COMPLETE__NEGATIVE_CONTROLS_PASS__ATOM_ONLY_PAIR_COMPOSITION_REJECTED"
        ),
        "scientific_interpretation": (
            "The full atomic spectra and geometry-resolved contact participation are now archived. "
            "If transfer fails, the missing object is not an atom-specific clock but the dynamical "
            "contact/coupling operator that selects and mixes atomic modes during molecular motion."
        ),
    }
    report_path = OUTPUTS / "BST_ATOMIC_SIGNATURE_AND_MODAL_COMPOSITION_AUDIT_R16.json"
    report_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    summary = [
        "# BST R16 — résultat",
        "",
        f"- Banque atomique : {len(signatures)}/118 atomes, {len(modes)} modes positifs.",
        f"- Contrôles nobles : {'7/7 non liés' if control_gate else 'échec'}.",
        f"- Transfert R10 tenu hors échelle : MAPE {100*holdout_metrics['mape']:.2f} %, "
        f"erreur maximale {100*holdout_metrics['maximum_relative_error']:.2f} %, "
        f"Spearman {holdout_metrics['spearman_rank']:.3f}.",
        f"- Verdict : `{report['verdict']}`.",
        "",
        "La banque des notes atomiques est désormais complète et conserve les mouvements géométriques "
        "accessibles dans le champ scalaire. La loi universelle n'est déclarée que si le transfert R10 passe.",
    ]
    (OUTPUTS / "BST_ATOMIC_SIGNATURE_R16_SUMMARY.md").write_text("\n".join(summary) + "\n", encoding="utf-8")
    manifest_path = HERE / "BST_ATOMIC_SIGNATURE_R16_MANIFEST_SHA256.json"
    manifest = {}
    for path in sorted(HERE.rglob("*")):
        if not path.is_file() or path == manifest_path or "__pycache__" in path.parts:
            continue
        manifest[str(path.relative_to(HERE))] = sha256(path)
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({
        "atom_count": len(signatures), "mode_count": len(modes),
        "negative_controls_pass": control_gate,
        "held_out_metrics": holdout_metrics,
        "universal_law_qualified": universal,
        "verdict": report["verdict"],
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
