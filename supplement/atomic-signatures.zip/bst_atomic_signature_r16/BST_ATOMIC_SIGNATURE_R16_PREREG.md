# BST R16 — Banque des signatures atomiques et composition spectrale

## Correction de cap

R15 réduisait chaque atome à quelques scalaires et cherchait une correction
globale de la fréquence moléculaire. R16 abandonne cette réduction. L'objet de
base est désormais le spectre propre complet de l'opérateur d'identité sous
charge de chacun des 118 atomes, avec ses vecteurs propres sur la géométrie de
surface correspondante.

## Données gelées

- opérateurs complets R6 (Z=1–36) et R9 (Z=37–118) ;
- géométries de surface R4 et V92-R1 ;
- panneau inférieur R8 : dix actions liées et quatre contrôles nobles ;
- panneau supérieur R10 : douze actions liées et trois contrôles nobles.

R8 sert uniquement à fixer une éventuelle conversion globale d'unité. R10 est
tenu hors de cette conversion et constitue le panneau de transfert. Aucun
coefficient propre à un atome, une paire ou une molécule n'est ajusté.

## Signature atomique

Pour chaque Z :

1. diagonaliser l'opérateur symétrisé `K` ;
2. retirer l'unique mode uniforme nul ;
3. définir les fréquences internes `omega_i = sqrt(lambda_i)` ;
4. projeter chaque mode sur les sous-espaces géométriques dipolaire (l=1),
   quadrupolaire (l=2), octupolaire (l=3) et résiduel ;
5. appliquer une charge de contact hémisphérique, sans largeur réglable,
   `f_j = max(n_j.d, 0)`, puis retirer sa moyenne et la normaliser. Pour une
   surface si clairsemée qu'aucun nœud ne tombe dans l'hémisphère visé, le
   nœud de produit scalaire maximal reçoit la charge unitaire ;
6. conserver les poids modaux `(v_i.f)^2`, la compliance, la latence modale et
   l'anisotropie sur 26 directions géométriques fixes.

Le champ de l'opérateur est scalaire. R16 ne rebaptise donc pas artificiellement
ses modes « longitudinaux » ou « transverses » : seuls les caractères
multipolaires réellement identifiables sont publiés.

## Composition de deux atomes

L'axe de séparation est l'axe x du calcul R8/R10. La géométrie du second atome
est transformée par la rotation déjà gelée dans l'action de paire. Les deux
raideurs de contact atomiques sont composées en série :

`k_pair = 1 / (1/k_left + 1/k_right)`

et la fréquence atomiquement prédite est :

`omega_pair = sqrt(k_pair / reduced_wave_mass)`.

Cette expression croise sans réglage supplémentaire la taille déjà contenue
dans les opérateurs V81, leur résistance/compliance, leur latence modale, la
forme et l'orientation des surfaces, et l'asymétrie des deux signatures. Les
accords candidats (différence, somme et composition quadratique des modes les
plus participants) sont archivés, mais aucun n'est sélectionné après lecture
de la cible.

## Portes universelles

- 118/118 opérateurs valides, avec un unique mode uniforme nul ;
- sept contrôles nobles non liés ;
- transfert R10 après une seule conversion globale éventuellement fixée sur R8 :
  MAPE <= 15 %, erreur maximale <= 25 %, corrélation de rang >= 0,90 ;
- aucune constante propre à une paire, molécule, famille ou élément.

L'échec d'une porte conserve la banque atomique mais interdit toute déclaration
de loi spectrale universelle.
