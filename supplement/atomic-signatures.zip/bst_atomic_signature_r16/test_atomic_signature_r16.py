#!/usr/bin/env python3
import json
import subprocess
import sys
from pathlib import Path


HERE = Path(__file__).resolve().parent
subprocess.run([sys.executable, str(HERE / "run_atomic_signature_r16.py")], check=True)
report = json.loads((HERE / "outputs/BST_ATOMIC_SIGNATURE_AND_MODAL_COMPOSITION_AUDIT_R16.json").read_text())
assert report["atomic_bank"]["atom_count"] == 118
assert report["atomic_bank"]["all_atoms_one_uniform_null_mode"] is True
assert report["method"]["molecule_specific_parameters"] == 0
assert report["method"]["element_specific_fitted_parameters"] == 0
assert report["negative_control_gate_pass"] is True
assert len(report["negative_controls"]) == 7
assert report["held_out_transfer"]["panel"].startswith("R10")
print("R16_TESTS_PASS")
