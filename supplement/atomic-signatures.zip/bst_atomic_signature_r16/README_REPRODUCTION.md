# Reproduction

Python 3.10+ et NumPy sont suffisants.

```bash
python3 test_atomic_signature_r16.py
```

Le script reconstruit la banque complète des modes atomiques, les poids
multipolaires, les accords de contact et l'audit de transfert R8 vers R10.
Les références spectrales moléculaires ne sont jamais utilisées pour choisir
un mode atomique ou un accord.
