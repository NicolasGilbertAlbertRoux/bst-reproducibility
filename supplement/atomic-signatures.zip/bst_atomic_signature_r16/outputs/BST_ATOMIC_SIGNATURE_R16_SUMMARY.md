# BST R16 — résultat

- Banque atomique : 118/118 atomes, 8812 modes positifs.
- Contrôles nobles : 7/7 non liés.
- Transfert R10 tenu hors échelle : MAPE 76.33 %, erreur maximale 91.06 %, Spearman 0.028.
- Verdict : `ATOMIC_SIGNATURE_BANK_COMPLETE__NEGATIVE_CONTROLS_PASS__ATOM_ONLY_PAIR_COMPOSITION_REJECTED`.

La banque des notes atomiques est désormais complète et conserve les mouvements géométriques accessibles dans le champ scalaire. La loi universelle n'est déclarée que si le transfert R10 passe.
