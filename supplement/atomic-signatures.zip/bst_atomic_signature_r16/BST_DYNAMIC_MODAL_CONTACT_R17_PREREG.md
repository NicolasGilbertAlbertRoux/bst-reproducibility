# BST R17 — préenregistrement du contact modal dynamique

## Résultat causal de R16

R16 établit la banque complète des signatures atomiques, mais rejette la
composition statique par compliances en série sur le panneau supérieur. La
fréquence moléculaire ne peut donc pas être choisie à partir des seuls spectres
isolés et d'une charge hémisphérique figée.

## Objet manquant

Le prochain objet à extraire est le contact natif dépendant du temps `D(t)` de
l'action moléculaire complète. Pour chaque pas et chaque atome, R17 projettera
le champ de charge/redistribution réellement calculé sur tous les vecteurs
propres atomiques R16. Les séries d'amplitudes et d'énergies modales seront
ensuite analysées sans consulter de raie expérimentale.

## Calcul préenregistré

1. reproduire l'action de paire avec les paramètres gelés R8/R10 ;
2. exporter `D(t)` et les champs gauche/droite à chaque pas ;
3. calculer `a_i(t)=v_i.D_left(t)` et `b_j(t)=v_j.D_right(t)` ;
4. retirer uniquement la moyenne temporelle, appliquer une fenêtre de Hann
   fixée et calculer les spectres de puissance ;
5. publier toutes les raies dépassant cinq fois le plancher médian, leurs
   largeurs, phases croisées, sommes et différences ;
6. définir la raie moléculaire BST comme la raie cohérente gauche-droite de
   puissance croisée maximale dans le mouvement radial, avant ouverture de la
   référence physique ;
7. appliquer une seule conversion d'unité, jamais un coefficient moléculaire.

## Nouvelles actions requises

La qualification universelle exigera un panneau frais choisi dans l'atlas de
propension avant ouverture des références, couvrant au minimum : hydrure
alcalin, halogénure alcalin, oxyde alcalino-terreux, oxyde covalent,
chalcogénure et halogène lourd. Une famille complète et au moins un élément de
chaque strate resteront hors de toute conversion ou sélection.

R8 et R10 pourront servir aux diagnostics et tests de reproduction, mais ne
seront plus présentés comme une validation indépendante fraîche de R17.

## Portes

- conservation de toutes les portes atomiques R16 et des sept témoins nobles ;
- identité de la raie choisie stable au raffinement temporel ;
- MAPE <= 10 % sur le panneau frais ;
- erreur maximale <= 20 % ;
- chaque famille aveugle MAPE <= 15 % ;
- aucune sélection de raie, largeur, seuil ou coefficient après lecture des
  fréquences expérimentales.
